package fiap.com.br.ecommerce.dto;

import fiap.com.br.ecommerce.entity.Role;
import fiap.com.br.ecommerce.entity.User;
import fiap.com.br.ecommerce.validation.Adult;
import fiap.com.br.ecommerce.validation.UserRoleValidation;
import jakarta.validation.constraints.*;
import org.hibernate.validator.constraints.br.CNPJ;
import org.hibernate.validator.constraints.br.CPF;

import java.time.LocalDate;

@UserRoleValidation
public record UserRequest(
     @NotBlank(message = "Name is required") //messages in code i18n ❌
     String name,

     @CPF
     String cpf,

     @CNPJ
     String cnpj,

     @Email
     String email,

     @Size(min = 8)
     String password,

     @Adult
     LocalDate birthDate,

     @Min(value = 1, message = "Rating must be at least 1")
     @Max(value = 5, message = "Rating must be at most 5")
     Integer rating,

     Role role
){
    public User toEntity() {
        return User.builder()
                .name(name)
                .cpf(cpf)
                .cnpj(cnpj)
                .email(email)
                .password(password)
                .birthDate(birthDate)
                .rating(rating)
                .role(role)
                .build();
    }
}
