package br.com.fiap.com.br.personagemRPG.dto;

import br.com.fiap.com.br.personagemRPG.entity.CharacterClass;
import br.com.fiap.com.br.personagemRPG.entity.Characters;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record CharacterRequest(

        @NotBlank
        @Pattern(regexp = "^CHAR-\\d{4}$", message = "Formato deve ser CHAR-1234")
        String characterCode,

        @NotBlank
        @Size(min = 3, max = 50)
        String name,

        @NotBlank
        @Email
        String email,

        CharacterClass characterClass,

        @NotNull
        @Min(12)
        @Max(120)
        Integer age,

        @NotNull
        @Min(1)
        @Max(100)
        Integer level,

        @NotNull
        @Min(0)
        Double hp,

        @NotNull
        @PastOrPresent
        LocalDate createdAt
) {

     public Characters toEntity(){
         return Characters.builder()
                 .characterCode(characterCode)
                 .name(name)
                 .email(email)
                 .characterClass(characterClass)
                 .age(age)
                 .level(level)
                 .hp(hp)
                 .createdAt(createdAt)
                 .build();
     }
}
