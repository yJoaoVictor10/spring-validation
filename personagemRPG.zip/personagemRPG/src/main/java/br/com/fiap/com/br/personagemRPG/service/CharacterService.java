package br.com.fiap.com.br.personagemRPG.service;

import br.com.fiap.com.br.personagemRPG.entity.Characters;
import br.com.fiap.com.br.personagemRPG.repository.CharacterRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CharacterService {

    private final CharacterRepository characterRepository;

    public CharacterService(CharacterRepository characterRepository) {
        this.characterRepository = characterRepository;
    }

    public Characters addCharacters(Characters character){
        return characterRepository.save(character);
    }

    public List<Characters> findAll(){
        return characterRepository.findAll();
    }
}
