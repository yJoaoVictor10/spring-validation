package br.com.fiap.com.br.personagemRPG;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonagemRpgApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonagemRpgApplication.class, args);
	}

}
