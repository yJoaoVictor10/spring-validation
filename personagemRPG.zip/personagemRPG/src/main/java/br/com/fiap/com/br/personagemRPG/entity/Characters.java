package br.com.fiap.com.br.personagemRPG.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Characters {
    @Id
    private String characterCode;
    private String name;
    private String email;
    private CharacterClass characterClass;
    private Integer age;
    private Integer level;
    private Double hp;
    private LocalDate createdAt;

}
