package br.com.fiap.com.br.personagemRPG.controller;

import br.com.fiap.com.br.personagemRPG.dto.CharacterRequest;
import br.com.fiap.com.br.personagemRPG.dto.CharacterResponse;
import br.com.fiap.com.br.personagemRPG.entity.Characters;
import br.com.fiap.com.br.personagemRPG.service.CharacterService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/characters")
public class CharacterController {

    private final CharacterService characterService;

    public CharacterController(CharacterService characterService) {
        this.characterService = characterService;
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Characters addCharacter(@RequestBody @Valid CharacterRequest characterRequest){
        return characterService.addCharacters(characterRequest.toEntity());
    }

    @GetMapping
    public List<CharacterResponse> findAll(){
        return characterService.findAll().stream()
                .map(CharacterResponse::fromEntity)
                .toList();
    }
}
