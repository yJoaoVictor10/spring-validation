package br.com.fiap.com.br.personagemRPG.entity;

public enum CharacterClass {
    WARRIOR,
    MAGE,
    ROGUE,
    PALADIN,
    ARCHER
}
