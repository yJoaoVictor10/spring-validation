package br.com.fiap.com.br.personagemRPG.repository;

import br.com.fiap.com.br.personagemRPG.entity.Characters;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CharacterRepository  extends JpaRepository<Characters, String> {
}
