package br.com.fiap.com.br.personagemRPG.dto;

import br.com.fiap.com.br.personagemRPG.entity.CharacterClass;
import br.com.fiap.com.br.personagemRPG.entity.Characters;

import java.time.LocalDate;

public record CharacterResponse(
        String characterCode,
        String name,
        String email,
        CharacterClass characterClass,
        Integer age,
        Integer level,
        Double hp,
        LocalDate createdAt
) {

    public static CharacterResponse fromEntity(Characters c){
        return new CharacterResponse(
                c.getCharacterCode(),
                c.getName(),
                c.getEmail(),
                c.getCharacterClass(),
                c.getAge(),
                c.getLevel(),
                c.getHp(),
                c.getCreatedAt()

        );
    }
}
