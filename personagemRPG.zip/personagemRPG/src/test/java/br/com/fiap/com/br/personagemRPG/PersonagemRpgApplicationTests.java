package br.com.fiap.com.br.personagemRPG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonagemRpgApplicationTests {

	@Test
	void contextLoads() {
	}

}
