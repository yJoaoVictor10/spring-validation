package br.com.fiap.com.br.e_commerce.controller;

import br.com.fiap.com.br.e_commerce.dto.UserRequest;
import br.com.fiap.com.br.e_commerce.entity.User;
import br.com.fiap.com.br.e_commerce.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public User addUser(@RequestBody @Valid UserRequest userRequest){
        return userService.addUser(userRequest.toEntity());
    }

    @GetMapping
    public List<UserResponse> findAll(){
        return userService.findAll();
    }
}
