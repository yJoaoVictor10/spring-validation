package br.com.fiap.com.br.e_commerce.dto;

import br.com.fiap.com.br.e_commerce.entity.User;

import java.time.LocalDate;

public record UserResponse(
        String name,

        String cpf,


        String email,

        String password,

        LocalDate birthDate,

        Integer rating
) {
    public static UserResponse fromEntity(User u) {
    }
}
