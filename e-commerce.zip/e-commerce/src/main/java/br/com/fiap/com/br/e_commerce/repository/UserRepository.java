package br.com.fiap.com.br.e_commerce.repository;

import br.com.fiap.com.br.e_commerce.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}
