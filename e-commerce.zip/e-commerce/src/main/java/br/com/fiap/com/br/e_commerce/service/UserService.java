package br.com.fiap.com.br.e_commerce.service;

import br.com.fiap.com.br.e_commerce.dto.UserResponse;
import br.com.fiap.com.br.e_commerce.entity.User;
import br.com.fiap.com.br.e_commerce.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private static UserService userService;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }


    public User addUser(User user){
        return userRepository.save(user);
    }

    public List<UserResponse> findAll (){

        return userService.findAll().stream()
                .map(UserResponse::fromEntity)
                .toList();
    }
}
