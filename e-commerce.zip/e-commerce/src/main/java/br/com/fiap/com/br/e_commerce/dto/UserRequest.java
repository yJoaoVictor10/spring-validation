package br.com.fiap.com.br.e_commerce.dto;

import br.com.fiap.com.br.e_commerce.entity.User;
import jakarta.validation.constraints.*;
import org.hibernate.validator.constraints.br.CPF;

import java.time.LocalDate;

public record UserRequest( // record para representar objetos imutaveis

        @NotBlank
         String name,

         @CPF
         String cpf,

         @Email
         String email,

         @Size(min = 8)
         String password,

         @Past
         LocalDate birthDate,

         @Min(1) @Max(5)
         Integer rating
) {

    public User toEntity() {
        return User.builder()
                .name(name)
                .email(email)
                .password(password)
                .birthDate(birthDate)
                .rating(rating)
                .build();
    }
}
